DUNE LEGACY TORNIE — ORIGINAL GAME PNGs

106 PNGs: the 70 existing game resources and 36 original Vanilla illustrations.
All 19 previously unillustrated unit entries and 19 Vanilla building entries now have an icon.
Soldier and trooper squad orders share their unit illustration.

Vanilla illustrations were exported from the first WSA frame in MENTAT.PAK with IBM.PAL from DUNE.PAK,
using the same 91 x 55 pixel sampling coordinates as the game engine. Original colors and backgrounds are retained.
The existing PNG resources are unchanged. Sprite sheets may contain several orientations or animation states.

Manifest.json records SHA-256 hashes and original source paths. Catalogue.csv lists dimensions and distributions.
Game version: 1.0.532. Repository: https://github.com/Torneko/dunelegacy-tornie

Credits: Dune Legacy contributors; Tornie / Tornie Panther; Dune II / Westwood Studios. Images retain their original rights.
